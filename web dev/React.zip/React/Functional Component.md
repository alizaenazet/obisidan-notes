```jsx
export default
function MyFuncionComponent() {

return(
<>
<h1>Function Component</h1>
<hr></hr>
</>

)
}
```

- Melakukan `export default` pada fungsi komponen 
- penamaan fungsi komponen wajib CamelCase  (**Salah** `myComp`, **Benar** `MyComp`)
- melakukan return pada isi komponen didalam fungsi komponen


