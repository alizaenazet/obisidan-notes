```
npm create vite@latest
```

masuk ke folder yang telah terbuat sesuai pilihan 

```
npm i
```
*pastikan inisiasi folder*

```
npm run dev
```
*vite telah dijalankan*

## Video :
<iframe width="560" height="315" src="https://www.youtube.com/embed/Rh3tobg7hEo?clip=UgkxEzIpb5nbnY1_55T7NZFYkpGsHoDqKmwn&amp;clipt=EJP8GBibphs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
